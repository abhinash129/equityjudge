package org.apache.commons.lang.text;

import java.text.Format;
import java.util.Locale;

public interface FormatFactory {
  Format getFormat(String paramString1, String paramString2, Locale paramLocale);
}


/* Location:              C:\Users\Quald\OneDrive\Desktop\GraphPattern\GraphPattern.war!\GraphPattern\WEB-INF\lib\apache-commons-lang.jar!\org\apache\commons\lang\text\FormatFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */