package org.apache.commons.lang.mutable;

public interface Mutable {
  Object getValue();
  
  void setValue(Object paramObject);
}


/* Location:              C:\Users\Quald\OneDrive\Desktop\GraphPattern\GraphPattern.war!\GraphPattern\WEB-INF\lib\apache-commons-lang.jar!\org\apache\commons\lang\mutable\Mutable.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */