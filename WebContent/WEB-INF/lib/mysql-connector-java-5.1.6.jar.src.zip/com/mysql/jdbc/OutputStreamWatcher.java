package com.mysql.jdbc;

interface OutputStreamWatcher {
  void streamClosed(WatchableOutputStream paramWatchableOutputStream);
}


/* Location:              C:\Users\Quald\OneDrive\Desktop\GraphPattern\GraphPattern.war!\GraphPattern\WEB-INF\lib\mysql-connector-java-5.1.6.jar!\com\mysql\jdbc\OutputStreamWatcher.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */