package com.mysql.jdbc;

import java.sql.SQLException;

public interface PingTarget {
  void doPing() throws SQLException;
}


/* Location:              C:\Users\Quald\OneDrive\Desktop\GraphPattern\GraphPattern.war!\GraphPattern\WEB-INF\lib\mysql-connector-java-5.1.6.jar!\com\mysql\jdbc\PingTarget.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */