/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EscapeProcessorResult
/*    */ {
/*    */   boolean callingStoredFunction = false;
/*    */   String escapedSql;
/* 42 */   byte usesVariables = 0;
/*    */ }


/* Location:              C:\Users\Quald\OneDrive\Desktop\GraphPattern\GraphPattern.war!\GraphPattern\WEB-INF\lib\mysql-connector-java-5.1.6.jar!\com\mysql\jdbc\EscapeProcessorResult.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */