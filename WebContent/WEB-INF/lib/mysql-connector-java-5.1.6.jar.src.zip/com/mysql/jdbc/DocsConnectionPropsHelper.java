/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DocsConnectionPropsHelper
/*    */   extends ConnectionPropertiesImpl
/*    */ {
/*    */   public static void main(String[] args) throws Exception {
/* 18 */     System.out.println((new DocsConnectionPropsHelper()).exposeAsXml());
/*    */   }
/*    */ }


/* Location:              C:\Users\Quald\OneDrive\Desktop\GraphPattern\GraphPattern.war!\GraphPattern\WEB-INF\lib\mysql-connector-java-5.1.6.jar!\com\mysql\jdbc\DocsConnectionPropsHelper.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */