package com.mysql.jdbc;

interface WriterWatcher {
  void writerClosed(WatchableWriter paramWatchableWriter);
}


/* Location:              C:\Users\Quald\OneDrive\Desktop\GraphPattern\GraphPattern.war!\GraphPattern\WEB-INF\lib\mysql-connector-java-5.1.6.jar!\com\mysql\jdbc\WriterWatcher.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */