/*     */ package com.mysql.jdbc.log;
/*     */ 
/*     */ import com.mysql.jdbc.SQLError;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogFactory
/*     */ {
/*     */   public static Log getLogger(String className, String instanceName) throws SQLException {
/*  57 */     if (className == null) {
/*  58 */       throw SQLError.createSQLException("Logger class can not be NULL", "S1009");
/*     */     }
/*     */ 
/*     */     
/*  62 */     if (instanceName == null) {
/*  63 */       throw SQLError.createSQLException("Logger instance name can not be NULL", "S1009");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  69 */       Class loggerClass = null;
/*     */       
/*     */       try {
/*  72 */         loggerClass = Class.forName(className);
/*  73 */       } catch (ClassNotFoundException nfe) {
/*  74 */         loggerClass = Class.forName(Log.class.getPackage().getName() + "." + className);
/*     */       } 
/*     */ 
/*     */       
/*  78 */       Constructor constructor = loggerClass.getConstructor(new Class[] { String.class });
/*     */ 
/*     */       
/*  81 */       return (Log)constructor.newInstance(new Object[] { instanceName });
/*  82 */     } catch (ClassNotFoundException cnfe) {
/*  83 */       SQLException sqlEx = SQLError.createSQLException("Unable to load class for logger '" + className + "'", "S1009");
/*     */ 
/*     */       
/*  86 */       sqlEx.initCause(cnfe);
/*     */       
/*  88 */       throw sqlEx;
/*  89 */     } catch (NoSuchMethodException nsme) {
/*  90 */       SQLException sqlEx = SQLError.createSQLException("Logger class does not have a single-arg constructor that takes an instance name", "S1009");
/*     */ 
/*     */ 
/*     */       
/*  94 */       sqlEx.initCause(nsme);
/*     */       
/*  96 */       throw sqlEx;
/*  97 */     } catch (InstantiationException inse) {
/*  98 */       SQLException sqlEx = SQLError.createSQLException("Unable to instantiate logger class '" + className + "', exception in constructor?", "S1009");
/*     */ 
/*     */ 
/*     */       
/* 102 */       sqlEx.initCause(inse);
/*     */       
/* 104 */       throw sqlEx;
/* 105 */     } catch (InvocationTargetException ite) {
/* 106 */       SQLException sqlEx = SQLError.createSQLException("Unable to instantiate logger class '" + className + "', exception in constructor?", "S1009");
/*     */ 
/*     */ 
/*     */       
/* 110 */       sqlEx.initCause(ite);
/*     */       
/* 112 */       throw sqlEx;
/* 113 */     } catch (IllegalAccessException iae) {
/* 114 */       SQLException sqlEx = SQLError.createSQLException("Unable to instantiate logger class '" + className + "', constructor not public", "S1009");
/*     */ 
/*     */ 
/*     */       
/* 118 */       sqlEx.initCause(iae);
/*     */       
/* 120 */       throw sqlEx;
/* 121 */     } catch (ClassCastException cce) {
/* 122 */       SQLException sqlEx = SQLError.createSQLException("Logger class '" + className + "' does not implement the '" + Log.class.getName() + "' interface", "S1009");
/*     */ 
/*     */ 
/*     */       
/* 126 */       sqlEx.initCause(cce);
/*     */       
/* 128 */       throw sqlEx;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Quald\OneDrive\Desktop\GraphPattern\GraphPattern.war!\GraphPattern\WEB-INF\lib\mysql-connector-java-5.1.6.jar!\com\mysql\jdbc\log\LogFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */