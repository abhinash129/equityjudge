package org.gjt.mm.mysql;

import com.mysql.jdbc.Driver;

public class Driver extends Driver {}


/* Location:              C:\Users\Quald\OneDrive\Desktop\GraphPattern\GraphPattern.war!\GraphPattern\WEB-INF\lib\mysql-connector-java-5.1.6.jar!\org\gjt\mm\mysql\Driver.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */